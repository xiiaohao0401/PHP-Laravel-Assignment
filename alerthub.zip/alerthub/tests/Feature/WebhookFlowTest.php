<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Project;
use App\Models\WebhookSource;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Queue;
use App\Jobs\ProcessWebhookEvent;

class WebhookFlowTest extends TestCase
{
    use RefreshDatabase;

    public function test_webhook_dispatches_job(): void
    {
        Queue::fake();

        $project = Project::factory()->create();

        $source = WebhookSource::factory()->create([
            'project_id' => $project->id,
            'is_active' => true,
        ]);

        $response = $this->postJson(
            "/api/webhooks/{$project->uuid}/{$source->source_key}",
            [
                'event_type' => 'alert.triggered',
                'source' => 'monitoring',
            ]
        );

        $response->assertStatus(202);

        Queue::assertPushed(
            ProcessWebhookEvent::class
        );
    }
}