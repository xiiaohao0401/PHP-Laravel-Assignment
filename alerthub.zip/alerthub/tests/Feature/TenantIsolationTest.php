<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Organization;
use Illuminate\Foundation\Testing\RefreshDatabase;

class TenantIsolationTest extends TestCase
{
    use RefreshDatabase;

    public function test_invalid_token_is_rejected(): void
    {
        $response = $this->getJson(
            '/api/projects',
            [
                'Authorization' => 'Bearer invalid-token',
            ]
        );

        $response->assertStatus(401);
    }

    public function test_valid_token_can_access_projects(): void
    {
        $organization = Organization::factory()->create();

        $response = $this->getJson(
            '/api/projects',
            [
                'Authorization' =>
                    'Bearer '.$organization->api_token,
            ]
        );

        $response->assertStatus(200);
    }
}