<?php

namespace Database\Factories;

use App\Models\AlertRule;
use App\Models\Notification;
use App\Models\Project;
use App\Models\Subscriber;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class NotificationFactory extends Factory
{
    protected $model = Notification::class;

    public function definition(): array
    {
        return [
            'uuid' => (string) Str::uuid(),

            'project_id' => Project::factory(),

            'subscriber_id' => Subscriber::factory(),

            'alert_rule_id' => null,

            'channel' => fake()->randomElement([
                'email',
                'webhook',
            ]),

            'subject' => fake()->sentence(),

            'body' => fake()->paragraph(),

            'payload' => [
                'priority' => fake()->randomElement([
                    'low',
                    'medium',
                    'high',
                    'critical',
                ]),
            ],

            'status' => fake()->randomElement([
                'pending',
                'sent',
                'failed',
            ]),

            'sent_at' => now(),
        ];
    }
}