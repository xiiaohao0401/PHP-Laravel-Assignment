<?php

namespace Database\Factories;

use App\Models\Project;
use App\Models\Subscriber;
use Illuminate\Database\Eloquent\Factories\Factory;

class SubscriberFactory extends Factory
{
    protected $model = Subscriber::class;

    public function definition(): array
    {
        return [
            'project_id' => Project::factory(),
            'email' => fake()->safeEmail(),
            'external_id' => fake()->uuid(),
            'name' => fake()->name(),
            'notification_count' => fake()->numberBetween(0, 100),
            'last_notified_at' => fake()->dateTimeBetween('-30 days', 'now'),
            'metadata' => [
                'source' => fake()->randomElement([
                    'github',
                    'stripe',
                    'monitoring',
                ]),
            ],
        ];
    }
}