<?php

namespace Database\Factories;

use App\Models\Project;
use App\Models\WebhookSource;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class WebhookSourceFactory extends Factory
{
    protected $model = WebhookSource::class;

    public function definition(): array
    {
        return [
            'project_id' => Project::factory(),

            'source_key' => Str::random(32),

            'source_type' => fake()->randomElement([
                'github',
                'stripe',
                'monitoring',
                'custom',
            ]),

            'name' => fake()->company(),

            'signing_secret' => Str::random(40),

            'event_mappings' => [
                'push' => 'code_push',
                'payment_failed' => 'billing_alert',
            ],

            'is_active' => true,
        ];
    }
}