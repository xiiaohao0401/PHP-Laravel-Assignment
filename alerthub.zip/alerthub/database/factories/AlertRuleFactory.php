<?php

namespace Database\Factories;

use App\Models\AlertRule;
use App\Models\Project;
use Illuminate\Database\Eloquent\Factories\Factory;

class AlertRuleFactory extends Factory
{
    protected $model = AlertRule::class;

    public function definition(): array
    {
        return [
            'project_id' => Project::factory(),

            'name' => fake()->words(3, true),

            'source_type' => fake()->randomElement([
                'github',
                'stripe',
                'monitoring',
                'custom',
            ]),

            'event_type' => fake()->randomElement([
                'push',
                'payment_failed',
                'server_down',
            ]),

            'conditions' => [
                'severity' => fake()->randomElement([
                    'low',
                    'medium',
                    'high',
                    'critical',
                ]),
            ],

            'action' => fake()->randomElement([
                'notify',
                'escalate',
                'digest',
            ]),

            'priority' => fake()->randomElement([
                'low',
                'medium',
                'high',
                'critical',
            ]),

            'is_active' => true,
        ];
    }
}