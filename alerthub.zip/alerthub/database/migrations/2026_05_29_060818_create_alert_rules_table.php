<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('alert_rules', function (Blueprint $table) {
            $table->id();

            $table->foreignId('project_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->string('name');

            $table->enum('source_type', [
                'github',
                'stripe',
                'monitoring',
                'custom',
            ]);

            $table->string('event_type');

            $table->json('conditions')
                ->nullable();

            $table->enum('action', [
                'notify',
                'escalate',
                'digest',
            ]);

            $table->enum('priority', [
                'low',
                'medium',
                'high',
                'critical',
            ]);

            $table->boolean('is_active')
                ->default(true);

            $table->timestamps();

            $table->index(['project_id']);
            $table->index(['source_type']);
            $table->index(['event_type']);
            $table->index(['is_active']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('alert_rules');
    }
};
