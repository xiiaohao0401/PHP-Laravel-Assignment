<?php

namespace Database\Seeders;

use App\Models\AlertRule;
use App\Models\Notification;
use App\Models\Organization;
use App\Models\Project;
use App\Models\Subscriber;
use App\Models\WebhookSource;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        Organization::factory()
            ->count(2)
            ->create()
            ->each(function ($organization) {

                Project::factory()
                    ->count(3)
                    ->create([
                        'organization_id' => $organization->id,
                    ])
                    ->each(function ($project) {

                        WebhookSource::factory()
                            ->count(2)
                            ->create([
                                'project_id' => $project->id,
                            ]);

                        AlertRule::factory()
                            ->count(3)
                            ->create([
                                'project_id' => $project->id,
                            ]);

                        Subscriber::factory()
                            ->count(10)
                            ->create([
                                'project_id' => $project->id,
                            ])
                            ->each(function ($subscriber) use ($project) {
                                $alertRule = AlertRule::where(
                                    'project_id',
                                    $project->id
                                )->inRandomOrder()->first();

                                Notification::factory()
                                    ->count(5)
                                    ->create([
                                        'project_id' => $project->id,
                                        'subscriber_id' => $subscriber->id,
                                        'alert_rule_id' => $alertRule?->id,
                                    ]);
                            });
                    });
            });
    }
}