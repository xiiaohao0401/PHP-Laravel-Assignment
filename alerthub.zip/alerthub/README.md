# AlertHub

A multi-tenant alert management platform built with Laravel.

## Overview

AlertHub allows organizations to receive webhook events from external services, evaluate alert rules, and dispatch notifications to subscribers.

The platform supports:

* Multi-tenant organization isolation
* Project-scoped resources
* Webhook ingestion
* Alert processing pipeline
* Queue-based notification delivery
* Event-driven side effects
* Legacy AlertMetrics integration

---

## Architecture

### Tenant Structure

```text
Organization
└── Project
    ├── Subscriber
    ├── AlertRule
    ├── Notification
    └── WebhookSource
```

All project resources are scoped to the authenticated organization.

---

## Authentication

Protected endpoints require:

```http
Authorization: Bearer {organization_api_token}
```

Organization resolution is handled by the `ResolveOrganization` middleware.

---

## API Endpoints

### Projects

| Method | Endpoint           |
| ------ | ------------------ |
| GET    | /api/projects      |
| POST   | /api/projects      |
| GET    | /api/projects/{id} |
| PUT    | /api/projects/{id} |

### Subscribers

| Method | Endpoint                       |
| ------ | ------------------------------ |
| GET    | /api/projects/{id}/subscribers |
| POST   | /api/projects/{id}/subscribers |

### Alert Rules

| Method | Endpoint                       |
| ------ | ------------------------------ |
| GET    | /api/projects/{id}/alert-rules |
| POST   | /api/projects/{id}/alert-rules |

### Notifications

| Method | Endpoint                         |
| ------ | -------------------------------- |
| GET    | /api/projects/{id}/notifications |

### Webhook Sources

| Method | Endpoint                           |
| ------ | ---------------------------------- |
| POST   | /api/projects/{id}/webhook-sources |

### Public Webhook Endpoint

```http
POST /api/webhooks/{project_uuid}/{source_key}
```

No authentication required.

---

## Alert Processing Pipeline

The webhook processing pipeline uses the Chain of Responsibility pattern.

### Handler Order

1. DeduplicationHandler
2. ValidationHandler
3. SubscriberMatchHandler
4. RuleEvaluationHandler
5. NotificationDispatchHandler

Possible handler outcomes:

* CONTINUE
* QUIT
* SKIP_TO_DISPATCH

---

## Events

### NotificationCreated

Triggered when a notification is created.

Listeners:

1. UpdateSubscriberStats
2. CheckEscalation

Execution order is important because escalation logic depends on updated subscriber statistics.

---

## Queue Jobs

### ProcessWebhookEvent

Processes incoming webhook payloads.

### SendNotification

Handles notification delivery.

Both jobs:

* Implement ShouldQueue
* Implement ShouldBeUnique
* Include retry handling
* Include failure handling

---

## Legacy Package Integration

Integrated AlertMetrics components:

* MetricsAggregator
* SubscriberResolver
* DigestScheduler
* EngagementScorer

Bug fixes are documented in `BUG_REPORT.md`.

---

## Database Seeding

Seed sample data:

```bash
php artisan migrate:fresh --seed
```

Generated data includes:

* 2 Organizations
* Multiple Projects
* Subscribers
* Alert Rules
* Notifications
* Webhook Sources

---

## Running the Application

Install dependencies:

```bash
composer install
```

Generate application key:

```bash
php artisan key:generate
```

Run migrations:

```bash
php artisan migrate
```

Seed database:

```bash
php artisan db:seed
```

Start server:

```bash
php artisan serve
```

Start queue worker:

```bash
php artisan queue:work
```

---

## Demo Flow

1. Authenticate using organization API token
2. Create a project
3. Register a webhook source
4. Create an alert rule
5. Send a webhook request
6. Process webhook through pipeline
7. Create notification
8. Dispatch notification job
9. Update subscriber metrics

---

## Design Decisions

* Organization-based tenant isolation
* Project-level resource scoping
* Chain of Responsibility for webhook processing
* Event-driven notification side effects
* Queue-based asynchronous processing
* Resource-based API responses
* Cursor/offset pagination support
