<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\ProjectController;
use App\Http\Controllers\Api\SubscriberController;
use App\Http\Controllers\Api\WebhookController;
use App\Http\Controllers\Api\AlertRuleController;
use App\Http\Controllers\Api\WebhookSourceController;
use App\Http\Controllers\Api\NotificationController;

Route::middleware('tenant')->group(function () {

    Route::get('/projects', [ProjectController::class, 'index']);

    Route::post('/projects', [ProjectController::class, 'store']);

    Route::get('/projects/{id}', [ProjectController::class, 'show']);

    Route::put('/projects/{id}', [ProjectController::class, 'update']);

    Route::get('/projects/{id}/subscribers', [SubscriberController::class, 'index']);

    Route::post('/projects/{id}/subscribers', [SubscriberController::class, 'store']);

    Route::get('/projects/{id}/alert-rules', [AlertRuleController::class, 'index']);

    Route::post('/projects/{id}/alert-rules', [AlertRuleController::class, 'store']);

    Route::post('/projects/{id}/webhook-sources', [WebhookSourceController::class, 'store']);

    Route::get('/projects/{id}/notifications', [NotificationController::class, 'index']);
});

Route::post(
    '/webhooks/{project_uuid}/{source_key}',
    [WebhookController::class, 'store']
);