# BUG REPORT

## AH-101 – Metrics dashboard shows wrong numbers

### Root Cause

MetricsAggregator calculated daily alert counts across all projects instead of filtering by the requested project. This caused alert totals from unrelated projects to be included in dashboard statistics.

### Fix Applied

Updated MetricsAggregator methods to accept and apply project_id filtering when calculating daily metrics and breakdowns.

### Regression Test

Created alerts for two different projects on the same date and verified that each project's metrics only included its own alerts.

### Prevention

Require tenant/project scoped queries for all reporting services and add automated tests for cross-project isolation.

---

## AH-102 – Webhooks from monitoring tools sometimes create duplicate subscribers or fail silently

### Root Cause

SubscriberResolver did not safely handle concurrent subscriber creation for payloads containing only external_id values. Simultaneous webhook processing could create duplicate records or fail to find a subscriber.

### Fix Applied

Added cache-based locking around subscriber creation and performed a second lookup after acquiring the lock before creating a new subscriber.

### Regression Test

Dispatched multiple monitoring webhook payloads simultaneously using the same external_id and verified only one subscriber record was created.

### Prevention

Use locking or database uniqueness constraints when creating shared resources under concurrent workloads.

---

## AH-103 – Alert digests are never scheduled with a delivery window

### Root Cause

Digest listener ordering was incorrect. CalculateDigestWindow depended on referenceId being generated first, but the listeners executed in the wrong order.

### Fix Applied

Reordered digest listeners so GenerateDigestId executes before CalculateDigestWindow.

### Regression Test

Triggered digest scheduling and verified scheduledWindow is populated correctly based on alert volume.

### Prevention

Document listener dependencies and add integration tests validating event pipeline ordering.

---

## AH-104 – During incidents, only the first alert digest is processed per subscriber

### Root Cause

ProcessAlertDigest implemented ShouldBeUnique with an overly restrictive uniqueness strategy that prevented legitimate digest jobs from executing during high alert volume periods.

### Fix Applied

Adjusted the uniqueness strategy so separate digest batches can be processed without being incorrectly suppressed.

### Regression Test

Queued multiple digest jobs for the same subscriber and verified each batch was processed.

### Prevention

Review uniqueness constraints carefully and test queue behavior under burst traffic conditions.

---

## AH-105 – Subscriber engagement scores are inconsistent between API and digest emails

### Root Cause

EngagementScorer cached engagement scores using only subscriberId. Realtime and digest contexts shared the same cache entry, causing one calculation to overwrite the other.

### Fix Applied

Updated cache keys to include the scoring context (realtime vs digest).

### Regression Test

Calculated both realtime and digest scores for the same subscriber and verified each returned its correct value.

### Prevention

Include all calculation inputs in cache keys and add tests covering multiple execution contexts.
