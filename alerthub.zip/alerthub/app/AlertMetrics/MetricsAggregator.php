<?php

namespace App\AlertMetrics;

use App\Models\Notification;
use Illuminate\Support\Facades\Cache;

class MetricsAggregator
{
    /**
     * Get daily alert count for a specific project.
     */
    public function getDailyAlertCount(
        int $projectId,
        string $date
    ): int {
        $cacheKey = "alert-metrics::{$projectId}::{$date}";

        return Cache::remember($cacheKey, 3600, function () use ($projectId, $date) {
            return Notification::query()
                ->where('project_id', $projectId)
                ->whereDate('created_at', $date)
                ->count();
        });
    }

    /**
     * Get hourly breakdown for a specific project.
     */
    public function getHourlyBreakdown(
        int $projectId,
        string $date
    ): array {
        $cacheKey = "alert-metrics::hourly::{$projectId}::{$date}";

        return Cache::remember($cacheKey, 1800, function () use ($projectId, $date) {
            return Notification::query()
                ->where('project_id', $projectId)
                ->whereDate('created_at', $date)
                ->selectRaw('HOUR(created_at) as hour, COUNT(*) as count')
                ->groupByRaw('HOUR(created_at)')
                ->pluck('count', 'hour')
                ->toArray();
        });
    }

    /**
     * Record an alert and invalidate project-specific cache.
     */
    public function recordAlert(int $notificationId): void
    {
        $notification = Notification::find($notificationId);

        if (! $notification) {
            return;
        }

        $projectId = $notification->project_id;
        $today = $notification->created_at->toDateString();

        Cache::increment(
            "alert-metrics::counter::{$projectId}::{$today}"
        );

        Cache::forget(
            "alert-metrics::{$projectId}::{$today}"
        );

        Cache::forget(
            "alert-metrics::hourly::{$projectId}::{$today}"
        );
    }

    /**
     * Get alert count for a project within a date window.
     */
    public function getAlertCountForWindow(
        int $projectId,
        string $startDate,
        string $endDate
    ): int {
        return Notification::query()
            ->where('project_id', $projectId)
            ->whereBetween('created_at', [$startDate, $endDate])
            ->count();
    }
}