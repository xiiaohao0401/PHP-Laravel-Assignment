<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\NotificationResource;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    public function index(Request $request, int $id)
    {
        $organization = $request->attributes->get('organization');

        $project = $organization
            ->projects()
            ->where('id', $id)
            ->firstOrFail();

        $query = $project->notifications();

        if ($request->filled('status')) {
            $query->where(
                'status',
                $request->status
            );
        }

        return NotificationResource::collection(
            $query->paginate(15)
        );
    }
}