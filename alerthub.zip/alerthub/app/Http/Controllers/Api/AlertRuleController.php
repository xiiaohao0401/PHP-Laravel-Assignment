<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\AlertRuleResource;
use App\Models\AlertRule;
use Illuminate\Http\Request;

class AlertRuleController extends Controller
{
    public function index(Request $request, int $id)
    {
        $organization = $request->attributes->get('organization');

        $project = $organization
            ->projects()
            ->where('id', $id)
            ->firstOrFail();

        return AlertRuleResource::collection(
            $project->alertRules()->paginate(15)
        );
    }

    public function store(Request $request, int $id)
    {
        $organization = $request->attributes->get('organization');

        $project = $organization
            ->projects()
            ->where('id', $id)
            ->firstOrFail();

        $validated = $request->validate([
            'name' => ['required', 'string'],
            'source_type' => ['required', 'string'],
            'event_type' => ['required', 'string'],
            'conditions' => ['nullable', 'array'],
            'action' => ['required', 'string'],
            'priority' => ['required', 'string'],
            'is_active' => ['boolean'],
        ]);

        $rule = AlertRule::create([
            'project_id' => $project->id,
            ...$validated,
        ]);

        return new AlertRuleResource($rule);
    }
}