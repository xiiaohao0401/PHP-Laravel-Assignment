<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\WebhookSourceResource;
use App\Models\WebhookSource;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class WebhookSourceController extends Controller
{
    public function store(Request $request, int $id)
    {
        $organization = $request->attributes->get('organization');

        $project = $organization
            ->projects()
            ->where('id', $id)
            ->firstOrFail();

        $validated = $request->validate([
            'source_type' => ['required', 'string'],
            'name' => ['required', 'string'],
            'signing_secret' => ['nullable', 'string'],
            'event_mappings' => ['nullable', 'array'],
        ]);

        $source = WebhookSource::create([
            'project_id' => $project->id,
            'source_key' => Str::random(20),
            'source_type' => $validated['source_type'],
            'name' => $validated['name'],
            'signing_secret' => $validated['signing_secret'] ?? null,
            'event_mappings' => $validated['event_mappings'] ?? [],
            'is_active' => true,
        ]);

        return new WebhookSourceResource($source);
    }
}