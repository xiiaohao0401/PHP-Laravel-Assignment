<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\SubscriberResource;
use App\Models\Project;
use App\Models\Subscriber;
use Illuminate\Http\Request;

class SubscriberController extends Controller
{
    public function index(Request $request, int $id)
    {
        $organization = $request->attributes->get('organization');

        $project = $organization
            ->projects()
            ->where('id', $id)
            ->firstOrFail();

        return SubscriberResource::collection(
            $project->subscribers()->paginate(15)
        );
    }

    public function store(Request $request, int $id)
    {
        $organization = $request->attributes->get('organization');

        $project = $organization
            ->projects()
            ->where('id', $id)
            ->firstOrFail();

        $validated = $request->validate([
            'email' => ['nullable', 'email'],
            'external_id' => ['nullable', 'string', 'max:255'],
            'name' => ['required', 'string', 'max:255'],
            'metadata' => ['nullable', 'array'],
        ]);

        $subscriber = Subscriber::create([
            'project_id' => $project->id,
            'email' => $validated['email'] ?? null,
            'external_id' => $validated['external_id'] ?? null,
            'name' => $validated['name'],
            'notification_count' => 0,
            'metadata' => $validated['metadata'] ?? [],
        ]);

        return new SubscriberResource($subscriber);
    }
}