<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Jobs\ProcessWebhookEvent;
use App\Models\Project;
use App\Models\WebhookSource;
use Illuminate\Http\Request;

class WebhookController extends Controller
{
    public function store(
        Request $request,
        string $project_uuid,
        string $source_key
    ) {
        $project = Project::where(
            'uuid',
            $project_uuid
        )->first();

        if (! $project) {
            return response()->json([
                'message' => 'Project not found.',
            ], 404);
        }

        $source = WebhookSource::where(
            'project_id',
            $project->id
        )
        ->where(
            'source_key',
            $source_key
        )
        ->where(
            'is_active',
            true
        )
        ->first();

        if (! $source) {
            return response()->json([
                'message' => 'Webhook source not found.',
            ], 404);
        }

        ProcessWebhookEvent::dispatch(
            $project->id,
            $source->id,
            $request->all()
        );

        return response()->json([
            'message' => 'Webhook accepted.',
        ], 202);
    }
}