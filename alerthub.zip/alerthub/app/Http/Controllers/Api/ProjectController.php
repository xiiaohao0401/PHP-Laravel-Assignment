<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\ProjectResource;
use App\Models\Project;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ProjectController extends Controller
{
    public function index(Request $request)
    {
        $organization = $request->attributes->get('organization');

        $projects = $organization
            ->projects()
            ->paginate(15);

        return ProjectResource::collection($projects);
    }

    public function show(Request $request, int $id)
    {
        $organization = $request->attributes->get('organization');

        $project = $organization
            ->projects()
            ->where('id', $id)
            ->firstOrFail();

        $includes = explode(
            ',',
            $request->query('includes', '')
        );

        $relationMap = [
            'subscribers' => 'subscribers',
            'alert_rules' => 'alertRules',
        ];

        $load = [];

        foreach ($includes as $include) {
            if (isset($relationMap[$include])) {
                $load[] = $relationMap[$include];
            }
        }

        $project->load($load);

        return new ProjectResource($project);
    }

    public function store(Request $request)
    {
        $organization = $request->attributes->get('organization');

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
        ]);

        $project = Project::create([
            'organization_id' => $organization->id,
            'uuid' => Str::uuid(),
            'name' => $validated['name'],
            'description' => $validated['description'] ?? null,
        ]);

        return new ProjectResource($project);
    }

    public function update(Request $request, int $id)
    {
        $organization = $request->attributes->get('organization');

        $project = $organization
            ->projects()
            ->where('id', $id)
            ->firstOrFail();

        $validated = $request->validate([
            'name' => ['sometimes', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
        ]);

        $project->update($validated);

        return new ProjectResource($project);
    }
}