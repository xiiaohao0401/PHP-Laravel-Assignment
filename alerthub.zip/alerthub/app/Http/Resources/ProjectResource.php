<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ProjectResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'uuid' => $this->uuid,
            'name' => $this->name,
            'description' => $this->description,

            'subscribers' => $this->whenLoaded('subscribers'),

            'alert_rules' => $this->whenLoaded('alertRules'),

            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}