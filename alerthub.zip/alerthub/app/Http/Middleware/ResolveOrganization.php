<?php

namespace App\Http\Middleware;

use App\Models\Organization;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ResolveOrganization
{
    public function handle(Request $request, Closure $next): Response
    {
        $header = $request->header('Authorization');

        if (! $header || ! str_starts_with($header, 'Bearer ')) {
            return response()->json([
                'message' => 'Unauthenticated.',
            ], 401);
        }

        $token = substr($header, 7);

        $organization = Organization::where(
            'api_token',
            $token
        )->first();

        if (! $organization) {
            return response()->json([
                'message' => 'Invalid organization token.',
            ], 401);
        }

        $request->attributes->set(
            'organization',
            $organization
        );

        return $next($request);
    }
}