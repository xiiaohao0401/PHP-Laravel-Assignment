<?php

namespace App\Jobs;

use Throwable;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class ProcessWebhookEvent implements ShouldQueue, ShouldBeUnique
{
    use Dispatchable;
    use InteractsWithQueue;
    use Queueable;
    use SerializesModels;

    public int $tries = 3;

    public array $backoff = [5, 15, 30];

    public int $uniqueFor = 300;

    protected int $projectId;

    protected int $sourceId;

    protected array $payload;

    public function __construct(
        int $projectId,
        int $sourceId,
        array $payload
    ) {
        $this->projectId = $projectId;
        $this->sourceId = $sourceId;
        $this->payload = $payload;
    }

    public function uniqueId(): string
    {
        return md5(
            $this->projectId .
            $this->sourceId .
            json_encode($this->payload)
        );
    }

    public function handle(): void
    {
        $project = \App\Models\Project::findOrFail(
            $this->projectId
        );

        $source = \App\Models\WebhookSource::findOrFail(
            $this->sourceId
        );

        $context = new \App\Pipeline\Context();

        $context->project = $project;

        $context->source = $source;

        $context->payload = $this->payload;

        $pipeline = new \App\Pipeline\AlertPipeline([
            new \App\Pipeline\Handlers\DeduplicationHandler(),
            new \App\Pipeline\Handlers\ValidationHandler(),
            new \App\Pipeline\Handlers\SubscriberMatchHandler(
                app(\App\AlertMetrics\SubscriberResolver::class)
            ),
            new \App\Pipeline\Handlers\RuleEvaluationHandler(),
            new \App\Pipeline\Handlers\NotificationDispatchHandler(),
        ]);

        $pipeline->process($context);
    }

    public function failed(Throwable $exception): void
    {
        Log::error('Webhook processing failed', [
            'project_id' => $this->projectId,
            'source_id' => $this->sourceId,
            'error' => $exception->getMessage(),
        ]);
    }
}