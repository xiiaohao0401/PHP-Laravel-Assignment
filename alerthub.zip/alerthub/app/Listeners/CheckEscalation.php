<?php

namespace App\Listeners;

use App\Events\NotificationCreated;

class CheckEscalation
{
    public function handle(NotificationCreated $event): void
    {
        $notification = $event->notification;

        $subscriber = $notification->subscriber;

        if (!$subscriber) {
            return;
        }

        /*
         * Example escalation rule:
         * More than 10 notifications
         * in the last 1 hour.
         */

        $recentCount = $subscriber
            ->notifications()
            ->where(
                'created_at',
                '>=',
                now()->subHour()
            )
            ->count();

        if ($recentCount > 10) {

            $notification->update([
                'status' => 'escalated',
            ]);
        }
    }
}