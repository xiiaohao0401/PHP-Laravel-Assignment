<?php

namespace App\Listeners;

use App\Events\NotificationCreated;

class UpdateSubscriberStats
{
    public function handle(NotificationCreated $event): void
    {
        throw new \Exception('UpdateSubscriberStats fired');
    }
}