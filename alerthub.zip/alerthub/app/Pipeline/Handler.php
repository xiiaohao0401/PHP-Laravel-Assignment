<?php

namespace App\Pipeline;

abstract class Handler
{
    public const CONTINUE = 'continue';

    public const QUIT = 'quit';

    public const SKIP_TO_DISPATCH = 'skip_to_dispatch';

    abstract public function handle(
        Context $context
    ): string;
}