<?php

namespace App\Pipeline;

class AlertPipeline
{
    protected array $handlers;

    public function __construct(array $handlers)
    {
        $this->handlers = $handlers;
    }

    public function process(Context $context): void
    {
        foreach ($this->handlers as $handler) {

            $result = $handler->handle($context);

            if ($result === Handler::QUIT) {
                return;
            }

            if ($result === Handler::SKIP_TO_DISPATCH) {
                break;
            }
        }
    }
}