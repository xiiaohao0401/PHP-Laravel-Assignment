<?php

namespace App\Pipeline\Handlers;

use App\Models\AlertRule;
use App\Pipeline\Context;
use App\Pipeline\Handler;
use Illuminate\Support\Facades\Log;

class RuleEvaluationHandler extends Handler
{
    public function handle(Context $context): string
    {
        $rules = AlertRule::where(
            'project_id',
            $context->project->id
        )
        ->where(
            'is_active',
            true
        )
        ->where(
            'source_type',
            $context->payload['source']
        )
        ->where(
            'event_type',
            $context->payload['event_type']
        )
        ->get();

        if ($rules->isEmpty()) {

            Log::info(
                'No matching alert rules found'
            );

            return self::QUIT;
        }

        $context->matchedRules = $rules->all();

        return self::CONTINUE;
    }
}