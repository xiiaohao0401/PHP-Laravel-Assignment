<?php

namespace App\Pipeline\Handlers;

use App\Events\NotificationCreated;
use App\Jobs\SendNotification;
use App\Models\Notification;
use App\Pipeline\Context;
use App\Pipeline\Handler;
use Illuminate\Support\Str;

class NotificationDispatchHandler extends Handler
{
    public function handle(Context $context): string
    {
        foreach ($context->matchedRules as $rule) {

            $notification = Notification::create([
                'uuid' => (string) Str::uuid(),

                'project_id' => $context->project->id,

                'subscriber_id' => $context->subscriber->id,

                'alert_rule_id' => $rule->id,

                'channel' => 'email',

                'subject' => 'Alert: ' . $rule->name,

                'body' => json_encode(
                    $context->payload
                ),

                'payload' => $context->payload,

                'status' => 'pending',
            ]);

            event(
                new NotificationCreated(
                    $notification
                )
            );

            SendNotification::dispatch(
                $notification->id
            );

            $context->notifications[] =
                $notification;
        }

        return self::CONTINUE;
    }
}