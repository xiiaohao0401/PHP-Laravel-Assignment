<?php

namespace App\Pipeline\Handlers;

use App\Pipeline\Context;
use App\Pipeline\Handler;
use Illuminate\Support\Facades\Log;

class ValidationHandler extends Handler
{
    public function handle(Context $context): string
    {
        $source = $context->payload['source'] ?? null;

        if (!$source) {
            Log::warning(
                'Webhook validation failed: missing source'
            );

            return self::QUIT;
        }

        $valid = match ($source) {
            'github' => $this->validateGithub($context->payload),
            'stripe' => $this->validateStripe($context->payload),
            'monitoring' => $this->validateMonitoring($context->payload),
            default => false,
        };

        if (!$valid) {

            Log::warning(
                'Webhook validation failed',
                ['source' => $source]
            );

            return self::QUIT;
        }

        return self::CONTINUE;
    }

    protected function validateGithub(array $payload): bool
    {
        return isset(
            $payload['event_type'],
            $payload['payload']['repository']
        );
    }

    protected function validateStripe(array $payload): bool
    {
        return isset(
            $payload['event_type'],
            $payload['payload']['customer']
        );
    }

    protected function validateMonitoring(array $payload): bool
    {
        return isset(
            $payload['event_type'],
            $payload['payload']['alert_id']
        );
    }
}