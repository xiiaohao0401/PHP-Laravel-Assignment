<?php

namespace App\Pipeline\Handlers;

use App\Pipeline\Context;
use App\Pipeline\Handler;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class DeduplicationHandler extends Handler
{
    public function handle(Context $context): string
    {
        $hash = md5(
            json_encode($context->payload)
        );

        $key = "webhook-dedupe:{$hash}";

        if (Cache::has($key)) {

            Log::info(
                'Duplicate webhook ignored',
                ['hash' => $hash]
            );

            return self::QUIT;
        }

        Cache::put(
            $key,
            true,
            now()->addMinutes(5)
        );

        return self::CONTINUE;
    }
}