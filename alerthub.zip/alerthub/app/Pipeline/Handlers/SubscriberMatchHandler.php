<?php

namespace App\Pipeline\Handlers;

use App\AlertMetrics\SubscriberResolver;
use App\Pipeline\Context;
use App\Pipeline\Handler;
use Illuminate\Support\Facades\Log;

class SubscriberMatchHandler extends Handler
{
    protected SubscriberResolver $resolver;

    public function __construct(
        SubscriberResolver $resolver
    ) {
        $this->resolver = $resolver;
    }

    public function handle(Context $context): string
    {
        $subscriber = $this->resolver->resolve(
            $context->project->id,
            $context->payload
        );

        if (!$subscriber) {

            Log::warning(
                'Subscriber resolution failed'
            );

            return self::QUIT;
        }

        $context->subscriber = $subscriber;

        return self::CONTINUE;
    }
}