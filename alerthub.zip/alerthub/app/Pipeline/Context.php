<?php

namespace App\Pipeline;

use App\Models\Project;
use App\Models\WebhookSource;
use App\Models\Subscriber;

class Context
{
    public ?Project $project = null;

    public ?WebhookSource $source = null;

    public ?Subscriber $subscriber = null;

    public array $payload = [];

    public array $matchedRules = [];

    public array $notifications = [];
}